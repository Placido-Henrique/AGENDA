package lab3;

/**
 * Um contato com índice, nome, sobrenome e telefone própios.
 * 
 * @author Plácido Henrique Araújo Vieira Lima
 */
public class Contato {
	/**
	 * índice do contato na agenda.
	 */
	private int indice;
	/**
	 * nome do contato.
	 */
	private String nome;
	/**
	 * sobrenome do contato.
	 */
	private String sobrenome;
	/**
	 * telefone do contato. 
	 */
	private String telefone;
	
	/**
	 * Construtor padrão do contato.
	 * 
	 * @param indice índice do contato na agenda.
	 * @param nome nome do contato.
	 * @param sobrenome sobrenome do contato.
	 * @param telefone telefone do contato. 
	 */
	public Contato (int indice,String nome, String sobrenome, String telefone) {
		this.indice = indice - 1;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.telefone = telefone;
	}
	
	
	/**
	 * Retorna o indice, nome e sobrenome do contato. Formato do contato na lista
	 * 
	 * @return uma string no formato "<INDICE> - <NOME> <SOBRENOME>"
	 */
	public String toStrLista() {
		return indice+1 + " - "+ nome + " " + sobrenome;
	}
	
	/**
	 * Retorna o nome, sobrenome e telefone do contato. Formato do contato ao ser
	 * exibido.
	 * 
	 * @return uma string no formato "<NOME> <SOBRENOME> - <TELEFONE>"
	 */
	public String toStrExibe() {
		return nome + " " + sobrenome + " - " + telefone;
	}

	/**
	 * Checa se o contato dado tem nome e sobrenome iguais aos do contato que
	 *  invoca o método.
	 * 
	 * @param c2 contato a ser comparado.
	 * @return valor boolean verdadeiro se os contatos forem iguais, ou false se
	 * não forem.
	 */
	public boolean equal(Contato c2) {
		if (this.nome.equals(c2.nome)  && this.sobrenome.equals(c2.sobrenome)) {
			return true;
		}
		return false;
	}
}