package lab3;

public class Contato {
	private int indice;
	private String nome;
	private String sobrenome;
	private String telefone;
	
	public Contato (int indice,String nome, String sobrenome, String telefone) {
		this.indice = indice - 1;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.telefone = telefone;
	}
	
	public String exibe() {
		return nome + " " + sobrenome + " " + telefone;
	}
	
	public String toStrLista() {
		return indice+1 + " - "+ nome + " " + sobrenome;
	}
	
	public String toStrExibe() {
		return nome + " " + sobrenome + " - " + telefone;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nome == null) ? 0 : nome.hashCode());
		result = prime * result + ((sobrenome == null) ? 0 : sobrenome.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Contato other = (Contato) obj;
		if (nome == null) {
			if (other.nome != null)
				return false;
		} else if (!nome.equals(other.nome))
			return false;
		if (sobrenome == null) {
			if (other.sobrenome != null)
				return false;
		} else if (!sobrenome.equals(other.sobrenome))
			return false;
		return true;
	}
	
	public boolean equal(Contato c2) {
		if (this.nome.equals(c2.nome) && this.indice == c2.indice && this.sobrenome.equals(c2.sobrenome) && this.telefone.equals(c2.telefone)) {
			return true;
		}
		return false;
	}

}