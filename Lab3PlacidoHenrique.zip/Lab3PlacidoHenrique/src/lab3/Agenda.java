package lab3;

import java.util.Arrays;

/**
 * Uma agenda telefônica simples, possui um nome para identifica-la e
 * armazena contatos com nome sobrenome e telefone.
 * 
 * @author Plácido Henrique Araújo Vieira Lima
 */
public class Agenda {
	/**
	 * Nome da agenda
	 */
	private String nome;
	/**
	 * Array que armazena os contatos da agenda, cuja capacidade total
	 * é de 100 contatos.
	 */
	private Contato[] contatos;

	/**
	 * Construtor padrão da agenda, que a atribui o nome recebido e uma capacidade
	 * de 100 contatos.
	 *
	 * @param nome é o nome da agenda
	 */
	public Agenda(String nome) {
		this.contatos = new Contato[100];
		this.nome = nome;
	}

	/**
	 * Cadastra um contato na agenda de acordo com as informações passadas.
	 * 
	 * @param pos posição do contato na agenda.
	 * @param nome nome do contato
	 * @param sobrenome sobrenome do contato
	 * @param telefone telefone do contato
	 */
	public void cadastraContato(int pos, String nome, String sobrenome, String telefone) {

		Contato contato = new Contato(pos, nome, sobrenome, telefone);
		this.contatos[pos - 1] = contato;
	}

	/**
	 * Retorna a lista de contatos presente na agenda
	 * 
	 * @return uma string que é uma lista de contatos com seus respectivos índices,
	 *  nomes e sobrenomes.
	 */
	public String listaContatos() {
		String saida = "";
		for (int i = 0; i < contatos.length; i++) {
			if (!contatoInexistente(i + 1)) {
				saida += this.contatos[i].toStrLista() + "\n";
			}
		}
		return saida;
	}

	/**
	 * Exibe o contato da agenda presente na posição selecionada.
	 * 
	 * @param indice posição do contato
	 * @return uma string com o nome, sobrenome e telefone do contato.
	 */
	public String exibeContato(int indice) {
		return this.contatos[indice - 1].toStrExibe();

	}

	/**
	 * Verifica se o contato da posição escolhida é inexistente.
	 * 
	 * @param pos posição do contato
	 * @return um valor boleano verdadeiro se o contato é null, ou false caso
	 * contrário.
	 */
	public boolean contatoInexistente(int pos) {
		return this.contatos[pos - 1] == null;
	}
	
	/**
	 * Checa se a agenda dada tem contatos iguais aos da agenda que invoca o método.
	 * 
	 * @param a2 agenda a ser comparada
	 * @return um valor boolean true se forem iguais, e false caso contrário.
	 */
	public boolean equal(Agenda a2) {
		int cont = 0;
		for (int i = 0; i < this.contatos.length; i++) {
			if (this.contatos[i].equal(a2.contatos[i])) {
				cont++;
			}
		}
		if (cont != 0) {
			return true;
		}
		return false;
	}
}