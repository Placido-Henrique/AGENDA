package lab3;

import java.util.Arrays;

public class Agenda {
	private String nome;
	private Contato[] contatos;

	public Agenda(String nome) {
		this.contatos = new Contato[100];
		this.nome = nome;
	}

	public void cadastraContato(int pos, String nome, String sobrenome, String telefone) {

		Contato contato = new Contato(pos, nome, sobrenome, telefone);
		this.contatos[pos - 1] = contato;
	}

	public String listaContatos() {
		String saida = "";
		for (int i = 0; i < contatos.length; i++) {
			if (!contatoNulo(i + 1)) {
				saida += this.contatos[i].toStrLista() + "\n";
			}
		}
		return saida;
	}

	public String exibeContato(int indice) {
		return this.contatos[indice - 1].toStrExibe();

	}

	public boolean contatoNulo(int pos) {
		return this.contatos[pos - 1] == null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(contatos);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Agenda other = (Agenda) obj;
		if (!Arrays.equals(contatos, other.contatos))
			return false;
		return true;
	}

	public boolean equal(Agenda a2) {
		int cont = 0;
		for (int i = 0; i < this.contatos.length; i++) {
			if (this.contatos[i].equal(a2.contatos[i])) {
				cont++;
			}
		}
		if (cont != 0) {
			return true;
		}
		return false;
	}
}