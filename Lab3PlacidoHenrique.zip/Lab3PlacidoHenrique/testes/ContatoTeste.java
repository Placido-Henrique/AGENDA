import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContatoTeste {

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testContato() {
		fail("Not yet implemented");
	}

	@Test
	void testExibe() {
		fail("Not yet implemented");
	}

	@Test
	void testToStrLista() {
		fail("Not yet implemented");
	}

	@Test
	void testToStrExibe() {
		fail("Not yet implemented");
	}

	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

	@Test
	void testEqual() {
		fail("Not yet implemented");
	}

}
