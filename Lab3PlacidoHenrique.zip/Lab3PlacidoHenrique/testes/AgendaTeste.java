import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class AgendaTeste {

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testAgenda() {
		fail("Not yet implemented");
	}

	@Test
	void testCadastraContato() {
		fail("Not yet implemented");
	}

	@Test
	void testListaContatos() {
		fail("Not yet implemented");
	}

	@Test
	void testExibeContato() {
		fail("Not yet implemented");
	}

	@Test
	void testContatoNulo() {
		fail("Not yet implemented");
	}

	@Test
	void testEqualsObject() {
		fail("Not yet implemented");
	}

}
